const allowed_origins = [
  "http://localhost:3000",
  "https://complend.shopgeorgia.ge",
];

module.exports = allowed_origins;
