const allowed_origins = ["http://localhost:3000"];

module.exports = allowed_origins;
